/** The site's panda mark. The same drawing is the browser-tab icon (app/icon.svg). */
export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg className="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width={size} height={size} aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#bfe3b4" />
      <circle cx="17" cy="19" r="9" fill="#23262b" />
      <circle cx="47" cy="19" r="9" fill="#23262b" />
      <ellipse cx="32" cy="35" rx="22" ry="20" fill="#fdfcf9" />
      <ellipse cx="22.5" cy="33" rx="6.2" ry="7.6" transform="rotate(20 22.5 33)" fill="#23262b" />
      <ellipse cx="41.5" cy="33" rx="6.2" ry="7.6" transform="rotate(-20 41.5 33)" fill="#23262b" />
      <circle cx="23.5" cy="32" r="2.4" fill="#fdfcf9" />
      <circle cx="40.5" cy="32" r="2.4" fill="#fdfcf9" />
      <path
        d="M29.2 41.2h5.6c.9 0 1.3 1 .7 1.7l-2.6 2.7a1.2 1.2 0 0 1-1.8 0l-2.6-2.7c-.6-.7-.2-1.7.7-1.7z"
        fill="#23262b"
      />
      <path
        d="M27 48.5c1.6 1.8 3.4 1.8 5 0 1.6 1.8 3.4 1.8 5 0"
        fill="none"
        stroke="#23262b"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
}
